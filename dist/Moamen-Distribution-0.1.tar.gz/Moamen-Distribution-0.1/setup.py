from setuptools import setup

setup(name='Moamen-Distribution',
      version='0.1',
      description='Gaussian distributions',
      packages=['distributions'],
      zip_safe=False)
